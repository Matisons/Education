# 03PTFE
Code for 03 Part-time Front-end Course
Each folder is the code for the 12 week part-time Front-End course at Codemaster Institute.
These are examples as well as exercises that students will complete during the lesson.
